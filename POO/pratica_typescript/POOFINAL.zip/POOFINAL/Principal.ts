import {Loja} from "./Loja";
let control: Loja;
control = new Loja();
control.init();


