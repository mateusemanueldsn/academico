import React, { Component } from 'react'
import ContratarPlano from '../commons/ContratarPlano'

export class CadastroPage3 extends Component {
    render() {
        return (
            <div>
                <ContratarPlano/>
            </div>
        )
    }
}

export default CadastroPage3
